import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  register = new FormGroup({
    firstName: new FormControl("John", [Validators.minLength(1), Validators.required]),
    lastName: new FormControl("Doe", [Validators.minLength(1), Validators.required]),
    email: new FormControl("abc@xyz.com", [Validators.email, Validators.required]),
    password: new FormControl("",[Validators.required,Validators.minLength(6)]),
    phone: new FormControl("1234567890", [Validators.minLength(10), Validators.required, Validators.maxLength(10)])
  });
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  onSubmit(){
    if(this.register.invalid){
      return;
    }else{
      console.log(this.register.value.firstName);
      console.log(this.register.value.lastName);
      console.log(this.register.value.email);
      console.log(this.register.value.phone);
      alert("User Registered");
      return this.router.navigate(['/login']);
    }
  }

  get formControl1(){
    return this.register.controls;
  }

}
