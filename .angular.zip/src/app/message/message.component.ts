import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {
  @Input() msg="";

  info: string="this is coming from message component";

  @Output()
  childmsg= new EventEmitter();

  sendMessage(){
    this.childmsg.emit(this.info);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
