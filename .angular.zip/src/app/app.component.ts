import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'decoratorsdemo';
  msg: string = "Hello!";
  newmsg:string='';

  receiveMessage(data: any){
    console.log(data);
    this.newmsg=data;
  }
}
